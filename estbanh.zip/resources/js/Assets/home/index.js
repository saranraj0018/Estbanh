import BannerSlider from "./banner-sider.png";
import FeedBackground from "./feed-bg.png";
import ProductBackground1 from "./ProductBG1.png";
import ProductBackground2 from "./ProductBG.png";
import ProductImage1 from "./Product1.png";
import ProductImage2 from "./Product2.png";
import ProductImage3 from "./Product3.png";
import PBG1 from "./pbg1.png";
import PBG2 from "./pbg2.png";
import PBG3 from "./pbg3.png";
import Section1Image from "./S1.png";
import Section2Product1 from "./Section2Prod1.png";
import Section2Product2 from "./Section2Prod2.png";
import Section2_2Product1 from "./Section2-2Prod1.png";
import Section2_2Product2 from "./Section2-2Prod2.png";
import Section2_2Product3 from "./Section2-2Prod3.png";
import Section3Product from "./Sec_3_product.png";
import Section3Product2 from "./Sec_3_product_2.png";
import Section3Product3 from "./Sec_3_product_3.png";
import Section3Product4 from "./Sec_3_product_4.png";
import Section3Product5 from "./Sec_3_product_5.png";
import Section3Product6 from "./Sec_3_product_6.png";
import Section3Product7 from "./Sec_3_product_7.png";
import Section4Product from "./Sec_4_Product.png";
import Section4Background from "./Sec4-BG.png";
import WhyChooseUsBackground from "./WCU-Bg.png";
import WhyChooseUsIcon1 from "./WCU-I1.png";
import WhyChooseUsIcon2 from "./WCU-I2.png";
import WhyChooseUsIcon3 from "./WCU-I3.png";
import WhyChooseUsIcon4 from "./WCU-I4.png";
import WhyChooseUsMain from "./WCU.png";

export {
  BannerSlider,
  FeedBackground,
  ProductBackground1,
  ProductBackground2,
  ProductImage1,
  ProductImage2,
  ProductImage3,
  PBG1,
  PBG2,
  PBG3,
  Section1Image,
  Section2Product1,
  Section2Product2,
  Section2_2Product1,
  Section2_2Product2,
  Section2_2Product3,
  Section3Product,
  Section3Product2,
  Section3Product3,
  Section3Product4,
  Section3Product5,
  Section3Product6,
  Section3Product7,
  Section4Product,
  Section4Background,
  WhyChooseUsBackground,
  WhyChooseUsIcon1,
  WhyChooseUsIcon2,
  WhyChooseUsIcon3,
  WhyChooseUsIcon4,
  WhyChooseUsMain,
};
